﻿namespace day1.Models
{
    public class ProductBL
    {
        List<Product> products;

        public ProductBL()
        {
            products = new List<Product>();

            products.Add(new Product() { Id = 1, name = "Arduino UNO", description = "Main item in the Project and has a CPU", price = 40, imag = "arduino.jpeg" });
            products.Add(new Product() { Id = 2, name = "Bluetooth", description = "Create small LAN Network", price = 15, imag = "bluetooth.jpeg" });
            products.Add(new Product() { Id = 3, name = "Speaker", description = "To make sounds", price = 7, imag = "speaker.jpeg" });
            products.Add(new Product() { Id = 4, name = "Stepper Motor", description = "to make moving in your project", price = 32, imag = "stepper motor.jpeg" });
        }

        public List<Product> GetAll()
        {
            return products;
        }

        public Product GetById(int id)
        {
            return products.FirstOrDefault(p => p.Id == id);
        }
    }
}

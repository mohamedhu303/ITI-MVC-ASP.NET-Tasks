﻿using day1.Models;
using Microsoft.AspNetCore.Mvc;

namespace day1.Controllers
{
    public class ProductController : Controller
    {
        public IActionResult ShowAll()
        {
            ProductBL productBL = new ProductBL();
            List<Product> productListModel = productBL.GetAll();
            return View("ShowAll", productListModel);
        }

        public IActionResult Details(int id) {
            ProductBL productBL = new ProductBL();
            Product productListModel = productBL.GetById(id);
            return View("Details",productListModel);
        }
    }
}

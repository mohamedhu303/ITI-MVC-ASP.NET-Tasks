﻿using day2.Models;
using day2.Models.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace day2.Controllers
{
    public class InstructorController : Controller
    {
        ProjectContext projectContext = new ProjectContext();

        public IActionResult Index()
        {
            List<Instructor> instrucorList = 
                projectContext.Instructor.Include(d=>d.Department).ToList();
            return View("Index",instrucorList);
        }

        public IActionResult Details (int id)
        {
            Instructor instructordetails =
                projectContext.Instructor.Include(e => e.Department)
                .FirstOrDefault(e => e.Id == id);

            //declare ViewModel
            InstructorInfoNameSalaryImageAddressDeptIDCrsIDViewModel InstVM = 
                new InstructorInfoNameSalaryImageAddressDeptIDCrsIDViewModel();

            //Mapping
            InstVM.Id = instructordetails.Id;
            InstVM.Name = instructordetails.Name;
            InstVM.salary = instructordetails.salary;
            InstVM.imag = instructordetails.imag;
            InstVM.address = instructordetails.address;
            InstVM.dept_name = instructordetails.Department.Name;

            return View("Details", InstVM);
        }
    }

}

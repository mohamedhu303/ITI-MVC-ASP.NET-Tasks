﻿using Microsoft.EntityFrameworkCore;
using System.Drawing;

namespace day2.Models
{
    public class ProjectContext:DbContext
    {
        public DbSet<Department> Department { get; set; }
        public DbSet<Instructor> Instructor { get; set; }
        public DbSet<Trainee> Trainee { get; set; }
        public DbSet<Course> Course { get; set; }
        public DbSet<crsResult> crsResult { get; set; }


        public ProjectContext() : base()
        {

        } 


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer
                ("Data Source=DESKTOP-SA79KUD;Initial Catalog=ITI_MVC;Integrated Security=True;Encrypt=False;Trust Server Certificate=True");
            base.OnConfiguring(optionsBuilder);
        }

    }
}

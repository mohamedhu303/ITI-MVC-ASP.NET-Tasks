﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace day2.Models
{
    public class crsResult
    {
        [Key]
        public int Id { get; set; }
        public int degee {  get; set; }
        [ForeignKey("Course")]
        public int crs_id { get; set; }
        [ForeignKey("Trainee")]
        public int Trainee_id { get; set; }

        public Course Course { get; set; }
        public Trainee Trainee { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace day2.Models
{
    public class Trainee
    {
        [Key]
        public int Id { get; set; }
        public string name {  get; set; }
        public string? imag {  get; set; }
        public string address { get; set; }
        public int grade { get; set; }
        [ForeignKey("Department")]
        public int dept_id {  get; set; }
        
        public Department Department { get; set; }

        //1:M Relations
        public List<crsResult> crsResults { get; set; }

    }
}

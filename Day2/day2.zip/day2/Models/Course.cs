﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace day2.Models
{
    public class Course
    {
        [Key]
        public int id { get; set; }
        public string name { get; set; }
        public int degree {  get; set; }
        public int minDegree { get; set; }
        [ForeignKey("Department")]
        public int dept_id { get; set; }

        public Department Department { get; set; }

        //1:M
        public List<crsResult> crsResults { get; set; }
    }
}

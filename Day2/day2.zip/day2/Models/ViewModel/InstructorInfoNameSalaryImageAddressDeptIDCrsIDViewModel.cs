﻿using System.ComponentModel.DataAnnotations.Schema;

namespace day2.Models.ViewModel
{
    public class InstructorInfoNameSalaryImageAddressDeptIDCrsIDViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string? imag { get; set; }
        public int salary { get; set; }
        public string address { get; set; }
        public string dept_name { get; set; }
        public string crs_name { get; set; }

    }
}

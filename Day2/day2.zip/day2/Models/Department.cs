﻿using System.ComponentModel.DataAnnotations;

namespace day2.Models
{
    public class Department
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public string Manager { get; set; }

        //1:M Relations 
        public List<Instructor> instructors { get; set; }
        public List<Course> courses { get; set; }
        public List<Trainee> trainees { get; set; }

    }
}
